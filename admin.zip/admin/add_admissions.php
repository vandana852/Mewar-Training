<!DOCTYPE html>
<html lang="en">
   <?php include('head.php');?>
    <body class="sb-nav-fixed">
 <?php include('nav.php');?>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <?php include('menu.php');?> 
            </div>
            <div id="layoutSidenav_content">
                <h1 class="mt-4">Add Students</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                            <li class="breadcrumb-item active">Add Students</li>
                        </ol>
                 <main>
                    <div class="container">
                        <div class="row justify-content-center">

                       <form method="post" action="insert_admission.php">
    <div class="row">
        <div class="col-md-6">
            <div class="form-floating mb-3">
                <input class="form-control" name="name" id="inputName" type="text" placeholder="Enter Name" />
                <label for="inputName">Name</label>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-floating mb-3">
                <input class="form-control" name="email" id="inputEmail" type="email" placeholder="Enter Email" />
                <label for="inputEmail">Email Address</label>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <div class="form-floating mb-3">
                <input class="form-control" id="inputPhone" name="phone" type="text" placeholder="Enter Phone Number" />
                <label for="inputPhone">Phone</label>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-floating mb-3">
                <input class="form-control" id="inputDOB" name="dob" type="date" placeholder="Enter Date of Birth" />
                <label for="inputDOB">Date of Birth</label>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <div class="form-floating mb-3">
                <input class="form-control" id="inputGuardianName" name="gaurdian_name" type="text" placeholder="Enter Guardian Name" />
                <label for="inputGuardianName">Guardian Name</label>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-floating mb-3">
                <input class="form-control" id="inputGuardianPhone" name="gaurdian_phone" type="text" placeholder="Enter Guardian Phone" />
                <label for="inputGuardianPhone">Guardian Phone</label>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <div class="form-floating mb-3">
                <input class="form-control" id="inputAadhaar" type="text" name="adhaar_num"  placeholder="Enter Aadhaar Number" />
                <label for="inputAadhaar">Aadhaar Number</label>
            </div>
        </div>
         <div class="col-md-6">
            <div class="form-floating mb-3">
        <select id="person_select" name="shift" class="form-control" required="">
                          <option value="">Choose Shift</option>
                          <option value="8:00-20:00(12 Hrs)">8:00-20:00(12 Hrs)</option>
                          <option value="8:00-16:00(8 Hrs)">8:00-16:00(8 Hrs)</option>
                          <option value="16:00-20:00(4 Hrs)">16:00-20:00(4 Hrs)</option>
                          <option value="08:00-12:00(4 Hrs)">08:00-12:00(4 Hrs)</option>
                          <option value="12:00-20:00(8 Hrs)">12:00-20:00(8 Hrs)</option>
                          <option value="8:00-20:00(12 Hrs) - Digital Library">8:00-20:00(12 Hrs) - Digital Library</option>
                        </select>
                    </div>
                </div>
       
    </div>
    <div class="row">
        <div class="col-md-6">
               <div class="form-floating mb-3">
        <select id="person_select" name="duration" class="form-control" required="">
                          <option value="">Choose Duration</option>
                          <option value="1 Month">1 Month</option>
                          <option value="3 Month">3 Month</option>
                        </select>
                    </div>
        </div>
         <div class="col-md-6">
            <div class="form-floating mb-3">
        <select id="person_select" name="payment_mode" class="form-control" required="">
                          <option value="">Payment Mode</option>
                          <option value="cash">Cash</option>
                          <option value="online">Online</option>
                        </select>
                    </div>
                </div>
        
    </div>
    <div class="row">
       
         <div class="col-md-6">
            <div class="form-floating mb-3">
        <select id="person_select" name="payment_status" class="form-control" required="">
                          <option value="">Payment Status(current month)</option>
                          <option value="Paid">Paid</option>
                          <option value="Unpaid">Unpaid</option>
                        </select>
                    </div>
                </div>
                 <div class="col-md-6">
            <div class="form-floating mb-3">
                <input class="form-control" id="inputAadhaar" type="text" name="fees"  placeholder="Enter Admission Fees" />
                <label for="inputAadhaar">Admission Fees</label>
            </div>
        </div>
       
    </div>
     <div class="col-md-6 d-flex align-items-center justify-content-between mt-4 mb-0">
             <input name="submit" type="submit" value="Submit" />
        </div>
</form>

                        </div>
                    </div>
                </main>
                
                <?php include('footer.php');?>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    </body>
</html>
