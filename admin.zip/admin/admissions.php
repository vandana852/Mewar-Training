<!DOCTYPE html>
<html lang="en">
   <?php include('head.php');?>
    <body class="sb-nav-fixed">
 <?php include('nav.php');?>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <?php include('menu.php');?> 
            </div>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">All Students</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
                            <li class="breadcrumb-item active">Tables</li>
                        </ol>
                        <!-- <div class="card mb-4">
                            <div class="card-body">
                                DataTables is a third party plugin that is used to generate the demo table below. For more information about DataTables, please visit the
                                <a target="_blank" href="https://datatables.net/">official DataTables documentation</a>
                                .
                            </div>
                        </div> -->
                        <div class="card mb-4">
                            <div class="card-header">
                                <i class="fas fa-table me-1"></i>
                                Students
                            </div>
                            <div class="card-body">
                                <table id="datatablesSimple">
                                    <thead>
                                        <tr>
                                               <th>S.No.</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Contact</th>
                                            <th>Gaurdian Name</th>
                                            <th>Gaurdian Phone</th>
                                            <th>Adhaar Number</th>
                                            <th>Shift</th>
                                            <th>Duration</th>
                                            <th>Fees</th>
                                            <th>Payment Mode</th>
                                            <th>Payment Status</th>

                                            <th>Date</th>
                                            
                                            
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <th>S.No.</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Contact</th>
                                            <th>Gaurdian Name</th>
                                            <th>Gaurdian Phone</th>
                                            <th>Adhaar Number</th>
                                            <th>Shift</th>
                                            <th>Duration</th>
                                            <th>Fees</th>
                                            <th>Payment Mode</th>
                                            <th>Payment Status</th>

                                            <th>Date</th>
                                        </tr>
                                    </tfoot>
                                    
                                          <?php
                                          $i = 1;
                                    include('../conn.php');
                                    $sql = "SELECT * FROM `students`";
                                    $result = mysqli_query($conn,$sql);
                                    while($row=mysqli_fetch_assoc($result))
                                    {


                                    ?>

                                    <tbody>                                    
                                        <tr>
                                            <td><?php echo $i++;?></td>
                                            <td><?php echo $row['name'];?></td>
                                            <td><?php echo $row['email'];?></td>
                                            <td><?php echo $row['phone'];?></td>
                                            <td><?php echo $row['gaurdian_name'];?></td>
                                            <td><?php echo $row['gaurdian_phone'];?></td>
                                            <td><?php echo $row['adhaar_num'];?></td>

                                            <td><?php echo $row['shift'];?></td>
                                            <td><?php echo $row['duration'];?></td>
                                            <td><?php echo $row['fees'];?></td>

                                            <td><?php echo $row['payment_mode'];?></td>
                                            <td><button class="btn btn-primary"><?php echo $row['payment_status'];?></button></td>
                                            <td><?php echo $row['datetime'];?></td>
                                        </tr>
                                        
                                    </tbody>
                                    <?php
                                   }
                                    ?>
                                       
                                    
                                </table>
                            </div>
                        </div>
                    </div>
                </main>

                 <?php include('footer.php');?>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    </body>
</html>
