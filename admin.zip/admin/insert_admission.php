<?php
include('../conn.php');
$insert = "insert into students (`name`,`email`,`phone`,`dob`,`gaurdian_name`,`gaurdian_phone`,`adhaar_num`,`shift`,`duration`,`fees`,`payment_mode`,`payment_status`) values ('".$_POST['name']."','".$_POST['email']."','".$_POST['phone']."','".$_POST['dob']."','".$_POST['gaurdian_name']."','".$_POST['gaurdian_phone']."','".$_POST['adhaar_num']."','".$_POST['shift']."','".$_POST['duration']."','".$_POST['fees']."','".$_POST['payment_mode']."','".$_POST['payment_status']."')";
mysqli_query($conn,$insert);
echo '<script>alert("Successfuly Added");window.location.href="http://localhost/library/admin/admissions.php";</script>';
?>